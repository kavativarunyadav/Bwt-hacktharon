import mongoose from 'mongoose';
const schema = new mongoose.Schema({
  user: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true, index: true },
  name: { type: String, required: true, trim: true, maxlength: 100 },
  description: { type: String, trim: true, maxlength: 300, default: '' },
  progress: { type: Number, min: 0, max: 100, default: 0 }
}, { timestamps: true });
schema.index({ user: 1, name: 1 }, { unique: true });
export default mongoose.model('Subject', schema);
