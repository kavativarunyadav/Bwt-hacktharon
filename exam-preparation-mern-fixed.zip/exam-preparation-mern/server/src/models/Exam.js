import mongoose from 'mongoose';
const schema = new mongoose.Schema({
  user: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true, index: true },
  title: { type: String, required: true, trim: true, maxlength: 150 },
  subject: { type: mongoose.Schema.Types.ObjectId, ref: 'Subject', default: null },
  date: { type: Date, required: true },
  notes: { type: String, trim: true, maxlength: 1000, default: '' }
}, { timestamps: true });
export default mongoose.model('Exam', schema);
