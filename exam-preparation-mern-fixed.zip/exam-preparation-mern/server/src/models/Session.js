import mongoose from 'mongoose';
const schema = new mongoose.Schema({
  user: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true, index: true },
  title: { type: String, required: true, trim: true, maxlength: 180 },
  subject: { type: mongoose.Schema.Types.ObjectId, ref: 'Subject', default: null },
  date: { type: Date, required: true },
  startTime: { type: String, required: true, match: /^([01]\d|2[0-3]):[0-5]\d$/ },
  endTime: { type: String, required: true, match: /^([01]\d|2[0-3]):[0-5]\d$/ },
  kind: { type: String, enum: ['focus', 'practice', 'revision', 'break'], default: 'focus' }
}, { timestamps: true });
export default mongoose.model('Session', schema);
