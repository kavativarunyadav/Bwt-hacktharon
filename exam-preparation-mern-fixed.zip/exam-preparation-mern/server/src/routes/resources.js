import { Router } from 'express';
import Subject from '../models/Subject.js';
import Task from '../models/Task.js';
import Exam from '../models/Exam.js';
import Session from '../models/Session.js';
import User from '../models/User.js';
import { protect, adminOnly } from '../middleware/auth.js';
const router = Router();
router.use(protect);
const models = { subjects: Subject, tasks: Task, exams: Exam, sessions: Session };
// Only tasks, exams, and sessions contain a `subject` reference.
const populateSubject = query => query.populate('subject', 'name');
const hasSubjectReference = type => type !== 'subjects';
const cleanObjectId = value => value && /^[a-f\d]{24}$/i.test(String(value)) ? value : null;
function ownerQuery(req) { return req.user.role === 'admin' && req.query.all === 'true' ? {} : { user: req.user._id }; }
function ownerBody(req, body) { return { ...body, user: req.user._id }; }
function pickFields(type, body) {
  if (type === 'subjects') return { name: body.name, description: body.description || '', progress: Number(body.progress ?? 0) };
  if (type === 'tasks') return { title: body.title, subject: cleanObjectId(body.subject), dueDate: body.dueDate || null, priority: body.priority || 'medium', estimatedHours: Number(body.estimatedHours ?? 1), completed: Boolean(body.completed) };
  if (type === 'exams') return { title: body.title, subject: cleanObjectId(body.subject), date: body.date, notes: body.notes || '' };
  return { title: body.title, subject: cleanObjectId(body.subject), date: body.date, startTime: body.startTime, endTime: body.endTime, kind: body.kind || 'focus' };
}
for (const type of Object.keys(models)) {
  const Model = models[type];
  router.get(`/${type}`, async (req, res) => {
    try { let query = Model.find(ownerQuery(req)).sort(type === 'subjects' ? { name: 1 } : { createdAt: -1 });
      if (hasSubjectReference(type)) query = populateSubject(query);
      const docs = await query; res.json(docs); }
    catch { res.status(500).json({ message: `Could not load ${type}.` }); }
  });
  router.post(`/${type}`, async (req, res) => {
    try { const data = pickFields(type, req.body);
      const doc = await Model.create(ownerBody(req, data));
      if (hasSubjectReference(type)) await doc.populate('subject', 'name');
      res.status(201).json(doc); }
    catch (e) { res.status(400).json({ message: e.code === 11000 ? 'That subject already exists.' : e.message || `Could not create ${type}.` }); }
  });
  router.patch(`/${type}/:id`, async (req, res) => {
    try {
      if (!cleanObjectId(req.params.id)) return res.status(400).json({ message: 'Invalid record ID.' });
      const filter = { _id: req.params.id, ...ownerQuery(req) };
      let query = Model.findOneAndUpdate(filter, pickFields(type, req.body), { new: true, runValidators: true });
      if (hasSubjectReference(type)) query = populateSubject(query);
      const doc = await query;
      if (!doc) return res.status(404).json({ message: 'Record not found.' });
      res.json(doc);
    } catch (e) { res.status(400).json({ message: e.message || 'Could not update record.' }); }
  });
  router.delete(`/${type}/:id`, async (req, res) => {
    try {
      if (!cleanObjectId(req.params.id)) return res.status(400).json({ message: 'Invalid record ID.' });
      const doc = await Model.findOneAndDelete({ _id: req.params.id, ...ownerQuery(req) });
      if (!doc) return res.status(404).json({ message: 'Record not found.' });
      res.json({ message: 'Deleted successfully.' });
    } catch { res.status(500).json({ message: 'Could not delete record.' }); }
  });
}
router.get('/admin/users', adminOnly, async (_req, res) => {
  const users = await User.find().select('_id name email role createdAt').sort({ createdAt: -1 });
  res.json(users);
});
router.get('/admin/summary', adminOnly, async (_req, res) => {
  const [users, subjects, tasks, exams, sessions] = await Promise.all([User.countDocuments(), Subject.countDocuments(), Task.countDocuments(), Exam.countDocuments(), Session.countDocuments()]);
  res.json({ users, subjects, tasks, exams, sessions });
});
export default router;
