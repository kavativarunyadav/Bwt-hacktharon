# Exam Preparation Dashboard (MERN)

A learning/demo MERN app with JWT signup/login, student/admin roles, subjects, study tasks, exam countdown, and timetable.

## Requirements
- Node.js 18+
- MongoDB local instance or MongoDB Atlas connection string

## Setup
1. Open this folder in VS Code.
2. In a terminal run `npm install` at the project root.
3. Run `npm run install:all`.
4. Copy `server/.env.example` to `server/.env` and set `MONGO_URI` and a long random `JWT_SECRET`.
5. Start MongoDB if using a local database.
6. Run `npm run dev` from the root.
7. Open http://localhost:5173

The API runs at http://localhost:5000. The first account created is a student. To create an admin, set `ALLOW_ADMIN_SIGNUP=true` temporarily in `server/.env`, restart the server, and choose Admin on signup. Turn it off again after creating the admin account. This is a demo convenience; for production, create admins through a trusted server-side process instead.

## Features
- Password hashing with bcryptjs and JWT authentication
- Role-based route guards; admin can view users and all records, students manage only their own records
- CRUD for subjects, tasks, timetable sessions, and exams
- Countdown and progress summaries
- Responsive React interface

## Notes
This is a starter project, not a production-hardened service. For deployment, use HTTPS, secure token storage/cookies, rate limiting, email verification, password reset, audit logging, and stricter admin provisioning.
## Bug fix: tasks not appearing after save

The resource API now populates the `subject` field only for tasks, exams, and timetable sessions. Subjects do not have a `subject` field, so populating it on the subjects endpoint caused `Cannot populate path \`subject\`` and broke the dashboard refresh. Replace your existing project with this updated version, restart the backend, and reload the frontend.
